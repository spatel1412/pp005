package Constant;

import java.io.File;

public class FilePathManager 
{
	public static String USER_DIRECTORY = System.getProperty("user.dir");

	public static String SEPARATOR = File.separator; 
	
	public static String TESTCASE_XCELFILEPATH = USER_DIRECTORY + SEPARATOR + "src" + SEPARATOR + "test" + SEPARATOR + "java" + SEPARATOR +"AvayaProfilerManager" + SEPARATOR + "data" + SEPARATOR +"PhonePeprofilermanagerdata.xlsx";

}
