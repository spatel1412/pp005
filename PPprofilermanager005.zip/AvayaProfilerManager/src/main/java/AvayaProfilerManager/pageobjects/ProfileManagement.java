package AvayaProfilerManager.pageobjects;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import AvayaProfilerManager.Abstractcomponents.AbstractComponentPP;

public interface ProfileManagement 

{
	void creation_of_Inbound_profile(Hashtable<String, String> testData) throws InterruptedException;

	void creation_of_Inbound_UI_profile(Hashtable<String, String> testData) throws InterruptedException;

	

	
}
