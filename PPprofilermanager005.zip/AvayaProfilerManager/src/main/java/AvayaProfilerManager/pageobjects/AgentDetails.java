package AvayaProfilerManager.pageobjects;

import java.time.Duration;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import AvayaProfilerManager.Abstractcomponents.AbstractComponentPP;
import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class AgentDetails extends AbstractComponentPP implements AgentManagement
{

	WebDriver driver;
	//Contact_list contact_list ; 

	public AgentDetails(WebDriver driver)
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public void creation_of_admin_user(Hashtable<String, String> testData) throws InterruptedException

	{
		System.out.println("creation_of_admin_user");
		 
		if(testData.get("UI_feature").equals("editbox"))
		{
			editBox(testData,driver);
		
			}
		if(testData.get("UI_feature").equals("dropdown"))
		{
			dropdown(testData,driver);
		
			}	
		if(testData.get("UI_feature").equals("click"))
		{
			click(testData,driver);
			
			}
		
		
	}
	
	public void deletion_of_admin_user(Hashtable<String, String> testData) throws InterruptedException
	
	{
		System.out.println("Entering into delete admin user");
		
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
    	if(testData.get("UI_feature").equals("editbox"))
		{
			editBox(testData,driver);
			}
		if(testData.get("UI_feature").equals("dropdown"))
		{
			dropdown(testData,driver);
			
			}	
		if(testData.get("UI_feature").equals("click"))
		{
			click(testData,driver);
			
			}	

		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		
	}
	
	public void creation_of_supervisor_user(Hashtable<String, String> testData) throws InterruptedException

	{ 
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));


		System.out.println("entered into create supervisor");
		
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
    	if(testData.get("UI_feature").equals("editbox"))
		{
			editBox(testData,driver);
			}
		if(testData.get("UI_feature").equals("dropdown"))
		{
			dropdown(testData,driver);
			
			}	
		if(testData.get("UI_feature").equals("click"))
		{
			click(testData,driver);
			
			}	
		
		JavascriptExecutor js = (JavascriptExecutor)driver ;
		js.executeScript("window.scrollBy(0,500)");
		
		
		}
	
	
	
	}

	

	
