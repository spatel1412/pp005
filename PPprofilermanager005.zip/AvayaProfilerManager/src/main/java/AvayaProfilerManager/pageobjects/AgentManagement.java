package AvayaProfilerManager.pageobjects;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import AvayaProfilerManager.Abstractcomponents.AbstractComponentPP;

public interface AgentManagement
{

	void creation_of_admin_user(Hashtable<String, String> testData) throws InterruptedException;

	void creation_of_supervisor_user(Hashtable<String, String> testData) throws InterruptedException;

	void deletion_of_admin_user(Hashtable<String, String> testData)  throws InterruptedException;

}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


