package AvayaProfilerManager.pageobjects;

import java.time.Duration;
import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import AvayaProfilerManager.Abstractcomponents.AbstractComponentPP;

public class TSAPIDetails extends AbstractComponentPP implements SystemManagement
{
	WebDriver driver;

	public TSAPIDetails(WebDriver driver)
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
		
public void creation_of_tsapi(Hashtable<String, String> testData) throws InterruptedException
	
	{
	System.out.println("Entering into ccreation_of_tsapi");

	
	if(testData.get("UI_feature").equals("editbox"))
	{
		editBox(testData,driver);
		}
	if(testData.get("UI_feature").equals("dropdown"))
	{
		dropdown(testData,driver);
		
		}	
	if(testData.get("UI_feature").equals("click"))
	{
		click(testData,driver);
		
		}	
	
			
	}
	
	
}
