package AvayaProfilerManager.pageobjects;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import AvayaProfilerManager.Abstractcomponents.AbstractComponentPP;

public interface SystemManagement 
{

	void creation_of_tsapi(Hashtable<String, String> testData) throws InterruptedException;


	
	
}
