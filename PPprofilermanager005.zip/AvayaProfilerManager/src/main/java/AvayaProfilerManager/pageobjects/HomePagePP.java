package AvayaProfilerManager.pageobjects;

import java.util.HashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.Hashtable;
import java.util.List;
import java.util.stream.Stream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.model.Log;

import AvayaProfilerManager.Abstractcomponents.AbstractComponentPP;


public class HomePagePP extends AbstractComponentPP

{
	WebDriver driver;
	//Contact_list contact_list ; 

	public HomePagePP(WebDriver driver)
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
		
	//AgentManagement agentdetails = new AgentDetails(driver);
	 AgentManagement agentdetails;
	 ProfileManagement inboundprofile;
	 ProfileManagement inbounduiprofile;
	 SystemManagement tsapidetails; 
	 //-----------------------------------------------------------------------------------------------------------------------//
	
	 public void creation_of_admin_user(Hashtable<String, String> testData) throws InterruptedException

	{
		agentdetails = new AgentDetails(driver);
		
		agentdetails.creation_of_admin_user(testData);
		//agentdetails.delete_user(testData);
		//agentdetails.delete_user(testData);
		//User_details user_details = new User_details(driver) ;
		//user_details.create_user(testData);
		//user_details.create_user2(testData);
	}

	

	public void creation_of_supervisor_user(Hashtable<String, String> testData) throws InterruptedException
	{
		agentdetails = new AgentDetails(driver);


		agentdetails.creation_of_supervisor_user(testData);
	}
	
	public void deletion_of_admin_user(Hashtable<String, String> testData) throws InterruptedException
	{
		agentdetails = new AgentDetails(driver);


		agentdetails.deletion_of_admin_user(testData);
	}
	
	//-----------------------------------------------------------------------------------------------------//
	//ProfileManagement
		public void creation_of_Inbound_profile(Hashtable<String, String> testData) throws InterruptedException

		{
			inboundprofile = new InboundProfile(driver);
			inboundprofile.creation_of_Inbound_profile(testData);
		}
	
		
		public void creation_of_Inbound_UI_profile(Hashtable<String, String> testData) throws InterruptedException

		{
			inbounduiprofile = new InboundUIProfile(driver);
			inbounduiprofile.creation_of_Inbound_UI_profile(testData);
		}
		
		
    //OutboundDisposition
	   public void OutboundDisposition(Hashtable<String, String> testData) throws InterruptedException
    {
					
				
    }
	
	 //contact_management	
	   public void contact_management(Hashtable<String, String> testData) throws InterruptedException 
	   {

	   		/*System.out.println("running from contact_list");
	   		contact_management_button.click(); 
	   		//contact_list =  new Contact_list(driver) ; 
	   		//contact_list.contact_list_click() ; 
	   		//contact_list.createcontact(testData) ; 
	   		Thread.sleep(5000) ; 
	   	
	   		*/
	   }  
		
	 //SystemManagement
	 		public void creation_of_tsapi(Hashtable<String, String> testData) throws InterruptedException

	 		{
	 			tsapidetails = new TSAPIDetails(driver);
	 			tsapidetails.creation_of_tsapi(testData);
	 		}
	   
	 		
	 //AuditDetails
	 		public void AuditDetails(Hashtable<String, String> testData) throws InterruptedException

	 		{
	 			
	 		}
	 	


}
