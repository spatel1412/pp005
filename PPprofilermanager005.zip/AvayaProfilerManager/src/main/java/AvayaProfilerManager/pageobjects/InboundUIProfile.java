package AvayaProfilerManager.pageobjects;

import java.time.Duration;
import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import AvayaProfilerManager.Abstractcomponents.AbstractComponentPP;


public class InboundUIProfile extends AbstractComponentPP implements ProfileManagement

{
	WebDriver driver;
	 

	public InboundUIProfile(WebDriver driver)
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	public void creation_of_Inbound_UI_profile(Hashtable<String, String> testData) throws InterruptedException

	{
		System.out.println("Entering into creation_of_Inbound_UI_profile");

		

	}


	@Override
	public void creation_of_Inbound_profile(Hashtable<String, String> testData) throws InterruptedException {
		// TODO Auto-generated method stub
		
	}

	
}
	
		
	

	



