package AvayaProfilerManager.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import AvayaProfilerManager.Abstractcomponents.AbstractComponentPP;

import java.io.IOException;
import java.nio.file.Files;
import org.json.JSONObject;
import java.net.URL;


import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.NoSuchElementException;

public class LoginpagePP extends AbstractComponentPP {

	WebDriver driver;

	public LoginpagePP(WebDriver driver)

	{
		super(driver);
		this.driver = driver;

		PageFactory.initElements(driver, this);
		}


	@FindBy(css = "div[class='panel-body'] div p[class='ng-binding']")
	WebElement errorMessage;
	
	public HomePagePP loginApplication(Hashtable<String, String> testData) throws InterruptedException, IOException
	{
		
		System.out.println("loginApplication1");
		
		System.out.println(testData.get("UI_feature"))	;
	 
		//Hashtable<String, String> t = new Hashtable<>();
		//parseExcelData(testData);
	if(testData.get("UI_feature").equals("editbox"))
	{
		editBox(testData,driver);
		}
	if(testData.get("UI_feature").equals("dropdown"))
	{
		dropdown(testData,driver);
		}	
	if(testData.get("UI_feature").equals("click"))
	{
		click(testData,driver);

		}	
	
	
	
		// Assertion data fetch
	String jsonText = System.getProperty("user.dir");
	 //C:\\Users\\patel806\\eclipse-workspace\\Phonepeprofiler\\AvayaProfilerManager\\src
		String jsonText1 = new String(Files.readAllBytes(Paths.get(
				""+ jsonText + "\\src\\test\\java\\AvayaprofilerManager\\data\\AssertionsData.json")));
		
		System.out.println("assertion path pass");
		JSONObject jsonObject = new JSONObject(jsonText1);
		String loginText = jsonObject.getString("LoginText");
		System.out.println("loginApplication1");
		//waitForWebElementToAppear(driver.findElement(By.cssSelector("div[class='ng-scope'] h2")));
		//String Actual = driver.findElement(By.cssSelector("div[class='ng-scope'] h2")).getText();
		//Assert.assertEquals(Actual, loginText);
		HomePagePP homepage = new HomePagePP(driver);
		System.out.println("welcome to homepage");
		
		Thread.sleep(3000);
		return homepage;

		}


	//----------------------------------------------------------------------------------------//

	public void loginFailed(Hashtable<String, String> testData)
	{
		System.out.println("loginFailed");
		//parseExcelData(testData);
		
		System.out.println(testData.get("UI_feature"))	;
	 
		//Hashtable<String, String> t = new Hashtable<>();
		//parseExcelData(testData);
	if(testData.get("UI_feature").equals("editbox"))
	{
		editBox(testData,driver);
		}
	if(testData.get("UI_feature").equals("dropdown"))
	{
		dropdown(testData,driver);
		}	
	if(testData.get("UI_feature").equals("click"))
	{
		click(testData,driver);

		}	
		
		
		
		
	}
	//----------------------------------------------------------------------------------------//

	public String getErrorMessage() {
		waitForWebElementToAppear(errorMessage);
		return errorMessage.getText();
	}

}
