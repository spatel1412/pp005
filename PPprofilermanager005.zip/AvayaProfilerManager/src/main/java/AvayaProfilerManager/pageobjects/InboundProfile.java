package AvayaProfilerManager.pageobjects;

import java.util.Hashtable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import AvayaProfilerManager.Abstractcomponents.AbstractComponentPP;

public class InboundProfile extends AbstractComponentPP implements ProfileManagement

{
	WebDriver driver;
	 

	public InboundProfile(WebDriver driver)
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	

	public void creation_of_Inbound_profile(Hashtable<String, String> testData) throws InterruptedException

	{
		System.out.println("Entering into creation_of_Inbound_profile");

		
		
		Thread.sleep(2000);
		System.out.println("6");

	}
	
	@Override
	public void creation_of_Inbound_UI_profile(Hashtable<String, String> testData) {
		// TODO Auto-generated method stub
		
	}

		
	}



	
		
	
	
	
	
	

