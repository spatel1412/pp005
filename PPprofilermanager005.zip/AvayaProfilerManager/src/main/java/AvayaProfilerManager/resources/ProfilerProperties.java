package AvayaProfilerManager.resources;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
 
import org.apache.log4j.Logger;



public class ProfilerProperties 
{
	private static final Logger LOGGER = Logger.getLogger(ProfilerProperties.class);
	//String propertyFileName = "profilerService.properties";
	public Properties getPropertyValues(String propertyFileName) throws IOException{
		Properties prop = new Properties();
		File configFile = null;
		InputStream input = null;
 
		try {
 
			//File configDir = new File(System.getProperty("catalina.base"), "profilerConfig");
	     File configDir = new File(System.getProperty("user.dir"), "profilerConfig");
			configFile = new File(configDir, propertyFileName);
			input = new FileInputStream(configFile);
			// load a properties file from class path, inside static method
			prop.load(input);
			prop.setProperty("filePath", configFile.getAbsolutePath());
		} catch (IOException ex) {
			//ex.printStackTrace();
			LOGGER.info("Inside Catch Exception  :" + propertyFileName);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return prop;
	}
}
	
	
