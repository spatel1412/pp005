package AvayaProfilerManager.resources;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReporterPP
{

	
	public static ExtentReports getReportObject()
	{
		String path =System.getProperty("user.dir")+"\\reports\\index.html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(path);
		
		reporter.config().setReportName("Web Automation Results");
		reporter.config().setDocumentTitle("AvayaProfilerManager Test Results");
		
		ExtentReports extent =new ExtentReports();
		
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "Shubham");
		extent.setSystemInfo("Profiler URL", "https://10.133.93.214:8443/profiler-manager");
		//OS ,//Browser
		return extent;
			
	}
}


//package Avayaprofiler.resources;	
//import com.aventstack.extentreports.ExtentReports;
//import com.aventstack.extentreports.reporter.ExtentSparkReporter;
//public class ExtentReporterNG 
//{
//	
//public static ExtentReports getReportObject()
//{
//	String path =System.getProperty("user.dir")+"//reports//index.html";
//	ExtentSparkReporter reporter = new ExtentSparkReporter(path);
//	reporter.config().setReportName("Web Automation Results");
//	reporter.config().setDocumentTitle("Test Results");
//	
//	ExtentReports extent =new ExtentReports();
//	extent.attachReporter(reporter);
//	extent.setSystemInfo("Tester", "Shubham Patel");
//	return extent;
//	
//	
//	
//	
//}
//}
