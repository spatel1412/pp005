
package AvayaProfilerManager.Abstractcomponents;

import java.time.Duration;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.codoid.products.fillo.Recordset;

import org.openqa.selenium.support.ui.Select;
public class AbstractComponentPP {

	WebDriver driver;

	public AbstractComponentPP(WebDriver driver) {
		this.driver = driver;
		//this.excelReader = new ExcelReader();
		PageFactory.initElements(driver, this);

	}

	public Boolean waitForElementToAppear(By findBy)

	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		if (wait.until(ExpectedConditions.visibilityOfElementLocated(findBy)) != null) {

			return true;
		}

		else {
			return false;
		}

	}

	public void waitForWebElementToAppear(WebElement findBy)

	{

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		wait.until(ExpectedConditions.visibilityOf(findBy));

	}
//Selectivedropdown
	public void selectdropdown(WebElement findBy, String string)

	{
		 try {
	           
	            Select dropdown = new Select(findBy);
	            dropdown.selectByVisibleText(string);
	        } catch (Exception e) {
	            System.out.println("Failed to select option: " + string + ". Error: " + e.getMessage());
	        }
	}
	
	//printing dropdown values
	public void printDropdownValues(WebDriver driver, WebElement dropdownLocator) {
        try {
            Select dropdown = new Select(dropdownLocator);
            List<WebElement> options = dropdown.getOptions();

            for (WebElement option : options) {
                System.out.println("Dropdown Option: " + option.getText());
            }
        } catch (Exception e) {
            System.out.println("Failed to print dropdown values. Error: " + e.getMessage());
        }
    }
	
	//----new changes------------------------------------//
	
	
	public void selectOptionFromDropdown(WebElement element, String optionText) 
	{
       
		
        Select dropdown = new Select(element);

        try {
            dropdown.selectByVisibleText(optionText);
        } catch (Exception e) {
            System.out.println("Option '" + optionText + "' not found in the dropdown.");
            // Handle the exception as needed (e.g., logging, reporting)
        }
    }
	
	
	public static By convertToBy(String locatorStrategy, String locatorValue) {
        switch (locatorStrategy.toLowerCase()) {
            case "id":
                return By.id(locatorValue);
            case "css":
                return By.cssSelector(locatorValue);
            case "name":
                return By.name(locatorValue);
            case "xpath":
                return By.xpath(locatorValue);
            // Add other locator strategies as needed
            default:
                throw new IllegalArgumentException("Invalid locator strategy: " + locatorStrategy);
        }
    }
	
	//changes 
	//latest
	/* private ExcelReader excelReader;
	
	 public void performTest() {
	        Recordset recordset = excelReader.readLocators("path/to/your/excel/file.xlsx", "Sheet1");

	        while (recordset.next()) {
	            String pageName = recordset.getField("PageName");
	            String elementName = recordset.getField("ElementName");
	            String locatorType = recordset.getField("LocatorType");
	            String locatorValue = recordset.getField("LocatorValue");

	            By locator = getLocator(locatorType, locatorValue);
	            WebElement element = driver.findElement(locator);

	            // Your test logic here using the element
	        }

	        excelReader.close();
	    }*/

	    private By getLocator(String locatorType, String locatorValue) {
	        switch (locatorType.toLowerCase()) {
	            case "id":
	                return By.id(locatorValue);
	            case "name":
	                return By.name(locatorValue);
	            case "xpath":
	                return By.xpath(locatorValue);
	            // Add more cases for other locator types as needed
	            default:
	                throw new IllegalArgumentException("Unsupported locator type: " + locatorType);
	        }
	    }
	

	    
	
	/*public WebElement (String Strategy, String locator, String execute)

	  switch (locatorType.toLowerCase()) {
      case "editbox":
          return user_ID.sendKeys(testData.get("elementvalue"));;
      case "name":
          return By.name(locatorValue);
      case "xpath":
          return By.xpath(locatorValue);
      // Add more cases for other locator types as needed
      default:
          throw new IllegalArgumentException("Unsupported locator type: " + locatorType);
  }
	*/
	
	//------------------------------------------------------//
		public void editBox(Hashtable<String, String> testData, WebDriver driver)
		{
			//if(testData.get("element").equals(elementName))
			//System.out.println(elementName);
			
				WebElement feature= driver.findElement(convertToBy(testData.get("Strategy"), testData.get("locator")));
				feature.sendKeys(testData.get("elementvalue"));
				
			
			}
		

		public void dropdown(Hashtable<String, String> testData, WebDriver driver)
		{
			//(testData.get("element").equals(elementName))
			//System.out.println(elementName);
				WebElement domain = driver.findElement(convertToBy(testData.get("Strategy"), testData.get("locator")));
				selectOptionFromDropdown( domain, testData.get("elementvalue"));
				printDropdownValues(driver, domain);
				
			}

		public void click(Hashtable<String, String> testData, WebDriver driver)
		{
			//if(testData.get("element").equals(elementName))
			//{System.out.println(elementName);
				WebElement buttonclick = driver.findElement(convertToBy(testData.get("Strategy"), testData.get("locator")));
				buttonclick.click();
			}
		
		
		
		
	
		//refreshing the webpage
		public void refresh()
		{
			driver.navigate().refresh();
			
		}
	
		
		
		
		
	//---splitting the excel data || 
	//
		public void parseExcelData(Hashtable<String, String> testData) {
			for (Map.Entry<String, String> entry : testData.entrySet()) {
				String key = entry.getKey();
				String val = entry.getValue();
				System.out.println("key : "+key+" ----- value : "+val);
			};
			String UIfeature = testData.get("UI_feature");
			String[] UIfeature_list = UIfeature.split("\\|");
			
			String Elem = testData.get("element");
			String[] element_list = Elem.split("\\|");
			
			String elemvalue = testData.get("elementvalue");
			String[] elemvalue_list = elemvalue.split("\\|");
			
			String locatorval = testData.get("locator");
			String[] locator_list = locatorval.split("\\|");
			
			String Strategy1 = testData.get("Strategy");
			String[] Strategy_list = Strategy1.split("\\|");
			
		for(int i =0;i<UIfeature_list.length ;i++ )
		{
			Hashtable<String, String> t = new Hashtable<>();
			t.put("UI_feature", UIfeature_list[i]);
			t.put("element", element_list[i]);
			t.put("elementvalue", elemvalue_list[i]);
			t.put("locator", locator_list[i]);
			t.put("Strategy", Strategy_list[i]);
		
			if(t.get("UI_feature").equals("editbox"))
			{
				editBox(t,driver);
				}
			if(t.get("UI_feature").equals("dropdown"))
			{
				dropdown(t,driver);
				}	
			if(t.get("UI_feature").equals("click"))
			{
				click(t,driver);

				}	
		
		
		}
		}
		
		
	
	
	
}
