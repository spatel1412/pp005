package AvayaProfilerManager;
import java.io.IOException;
import java.util.Hashtable;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.AssertJUnit;
import org.testng.annotations.*;


import AvayaProfilerManager.pageobjects.HomePagePP;
import AvayaProfilerManager.pageobjects.LoginpagePP;
import AvayaProfilerManager.testcomponent.BaseTest;
import AvayaProfilerManager.testcomponent.SuiteListener;
import Constant.FilePathManager;

@Listeners(SuiteListener.class)
public class MainClass extends BaseTest {

	private static final Logger log = LogManager.getLogger(MainClass.class);

	HomePagePP homepage;
	LoginpagePP login_page;
	private String sheetname;
    private String EXcelfilepath;
	
   
  
//-------------------------------------------------------------------------------------------------------------//
//TEST CASES!!	

	//login Test Case
	@Test(enabled = false,dataProvider = "getData", groups = { "loginwithsearch" }, priority=1)
	public <loginApplication> void Login(Hashtable<String, String> testData)
			throws InterruptedException, IOException {
		String expectedWelcomeMessage = "Welcome to Avaya Agent Profile Manager";
		   // Read Test Data
	    log.info("Reading Input details...");
	    log.info("Test Data : -" + testData);
		log.info("Getting the title of the page" + driver.getTitle());
		
		String filepath = testData.get("Test_Path");
		String sheetname = testData.get("Test_Sheet_Name");
		Hashtable[] temp =  excelDataReader(filepath,"SELECT * FROM "+ sheetname );
		
		for (Hashtable h: temp)
		{Hashtable<String, String> data=new Hashtable(h);
			this.homepage = login.loginApplication(data);	
			System.out.println(data.get("Type") + "    " + data.get("UI_feature"));
			if ( data.get("UI_feature").equals("refresh"))
			{
				Thread.sleep(2000);
				
					driver.navigate().refresh();
					System.out.println("loginfail");
				
				
			}
		}
		System.out.println(testData.get("UI feature")+ testData.get("element") + testData.get("elementvalue") +  testData.get("locator") + testData.get("Strategy") );
		//this.homepage = login.loginApplication(data);
		//Assert.assertEquals(homepage.Get_Welcome_Message(), expectedWelcomeMessage);
		log.info("___________________________________________");
		
	}
	
//	@DataProvider
//	public Hashtable[] getData() throws IOException {
//
//		log.info("login  the user and fetching the data from excel");
//		return excelDataReader(
//			System.getProperty("user.dir")
//						+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
//				"SELECT * FROM Sheet1 WHERE Feature = 'Login'");
//	}
	
	
	
	

	//Positive Test Case
	//@Parameters({"browserName"})
	@Test(enabled = true,dataProvider = "getData1", groups = { "loginwithsearch" }, priority=1)
	public <loginApplication> void PositiveLogin2(Hashtable<String, String> testData)
			throws InterruptedException, IOException {
		   // Read Test Data
	    log.info("Reading Input details...");
	  //  log.info("Test Data : -" + testData);
		// context.setAttribute("testData", testData);
		//System.out.println("Excel File Path: " + EXcelfilepath);
       // System.out.println("Sheet Name: " + sheetname);
		String expectedWelcomeMessage = "Welcome to Avaya Agent Profile Manager";
		log.info("Getting the title of the page" + driver.getTitle());
		//System.out.println(testData.get("UI feature")+ testData.get("element") + testData.get("elementvalue") +  testData.get("locator") + testData.get("Strategy") );
		this.homepage = login.loginApplication(testData);
		
		//Assert.assertEquals(homepage.Get_Welcome_Message(), expectedWelcomeMessage);
		log.info("___________________________________________");
		
	}
// Negative Test Case
	@Test(enabled = false,dataProvider = "getData1", groups = { "negativeTest"}, priority=2)
	public <loginApplication> void NegativeLogin(Hashtable<String, String> testData)
			throws InterruptedException, IOException

	{
		System.out.println(driver.getTitle());
		   // Read Test Data
	    log.info("Reading Input details...");
	    log.info("Test Data : -" + testData);
//		if ( testData.get("UI_feature").equals("openBrowser"))
//		{
//			initializeDriver();
//		}
//		if ( testData.get("UI_feature").equals("navigate"))
//	{
//		driver.get(URL);
//}
		login.loginFailed(testData);
		AssertJUnit.assertFalse(false);
		Thread.sleep(2000);
//		if(testData.get("element").equals("login"))
//			driver.navigate().refresh();
//			System.out.println("loginfail");

		if ( testData.get("UI_feature").equals("refresh"))
		{
			Thread.sleep(2000);
			
				driver.navigate().refresh();
				System.out.println("loginfail");
				Thread.sleep(2000);	
		}
		 //context.setAttribute("testData", testData);
	}
	
//	@DataProvider
//
//	public Object[][] getLogindata()
//	{
//
//	Object data[][] = testUtil.getTestData("Sheet2");
//
//	return data;
//
//	}
//	
	
	
	
//AgentManagement_creation_of_admin_user

	@Test(enabled = false, dataProvider = "getData",  groups = "loginwithsearch",priority=4)

	public void AgentManagement_creation_of_admin_user(Hashtable<String, String> testData)
			throws InterruptedException, IOException 
	{
		System.out.println("hello create admin started");
		log.info("Creating the user " + driver.getTitle());
		this.homepage = login.loginApplication(testData);
		

		System.out.println(testData.get("AgentId") + "from agentid");
		//homepage.creation_of_admin_user(testData);
		// homepage.delete_user(testData);
		log.info("____________________________________________________" + driver.getTitle());

	}

//AgentManagement
	

//creation_of_supervisor_user//

	@Test(enabled = false, dataProvider = "getData", dependsOnMethods = "PositiveLogin", groups = "loginwithsearch")

	public void AgentManagement_creation_of_supervisor_user(Hashtable<String, String> testData)
			throws InterruptedException, IOException {

		log.info("Creating the user " + driver.getTitle());
		this.homepage = login.loginApplication(testData);

		//homepage.creation_of_supervisor_user(testData);

		log.info("____________________________________________________" + driver.getTitle());

	}

//-----------------------------------------------------------//	
//AgentManagement_deletion_of_admin_user//
	@Test(enabled = false, dataProvider = "delete_admin_user", dependsOnMethods = "PositiveLogin", groups = "loginwithsearch")
	public void AgentManagement_deletion_of_admin_user(Hashtable<String, String> testData)
			throws InterruptedException, IOException {

		log.info("deleting the admin user " + driver.getTitle());

		homepage.deletion_of_admin_user(testData);

		log.info("____________________________________________________" + driver.getTitle());

	}

//---------------------------------------------------------------------//
//ProfileManagement//
//creation_of_Inbound_profile//
	@Test(enabled = false, dataProvider = "creation_of_Inbound_profile",priority=3)

	public void ProfileManagement_creation_of_Inbound_profile(Hashtable<String, String> testData)
			throws InterruptedException, IOException {

		log.info("Creating the user " + driver.getTitle());
		this.homepage = login.loginApplication(testData);
		

		System.out.println("creation_of_Inbound_profile");

	homepage.creation_of_Inbound_profile(testData);
		log.info("____________________________________________________" + driver.getTitle());

	}

//creation_of_Inbound_UI_profile//
	@Test(enabled = false, dataProvider = "creation_of_Inbound_UI_profile", dependsOnMethods = "PositiveLogin", groups = "loginwithsearch")

	public void ProfileManagement_creation_of_Inbound_UI_profile(Hashtable<String, String> testData)
			throws InterruptedException, IOException {

		log.info("Creating the user " + driver.getTitle());
		System.out.println("creation_of_Inbound_UI_profile");

		homepage.creation_of_Inbound_UI_profile(testData);
		log.info("____________________________________________________" + driver.getTitle());

	}
//--------------------------------------------------------------------------//	
//SystemManagement//

	@Test(enabled = false, dataProvider = "creation_of_tsapi", dependsOnMethods = "PositiveLogin", groups = "loginwithsearch")

	public void SystemManagement_creation_of_tsapi(Hashtable<String, String> testData)
			throws InterruptedException, IOException {

		log.info("Creating the tsapi " + driver.getTitle());
		System.out.println("Test for Tsapi");

		homepage.creation_of_tsapi(testData);
		log.info("____________________________________________________" + driver.getTitle());

	}
	
//------------------------------------------------------------------------------------------------------------------------
//DATA PROVIDER WRT TESTCASES

	// data provider for contact management create contact

	/*@DataProvider
	public Hashtable[] getcreatecontactData() throws IOException {
		log.info("getting the create contact data from excel" + driver.getTitle());

		return excelDataReader(
				System.getProperty("user.dir")
						+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
				"SELECT * FROM Contactdeatilsform WHERE Run = 'YES' ");
	}
*/
	
	
	
	
	//-----------------------------------------------//
	// invoking data
	// Positive Test Case
	/*@DataProvider
	public Hashtable[] getData() throws IOException {

		log.info("login  the user and fetching the data from excel");
		return excelDataReader(
			System.getProperty("user.dir")
						+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
				"SELECT * FROM Sheet2 WHERE Testcase_ID = 'Verify_admin_login' AND RUN= 'YES'");
	}
	*/
//		
//		@DataProvider
//		
//		public Hashtable[] getData1() throws IOException {
//           String sheetname = "Sheet2";
//           String EXcelfilepath = "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx";
//			log.info("login  the user and fetching the data from excel");
//			return excelDataReader(
//				System.getProperty("user.dir")
//							+ EXcelfilepath ,
//					"SELECT * FROM "+sheetname+" WHERE Testcase_ID ='Verify_admin_login' AND RUN= 'YES'");
//			
//		}
	
	
@DataProvider
	public static Hashtable[] getData1()  {
      String sheetname = "login";
     String EXcelfilepath = "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx";
     //String EXcelfilepath = FilePathManager.TESTCASE_XCELFILEPATH;
	log.info("login  the user and fetching the data from excel");
	return excelDataReader(
		System.getProperty("user.dir")
					+ EXcelfilepath ,
			"SELECT * FROM "+sheetname+" WHERE Testcase_ID ='Verify_admin_login' AND RUN= 'YES'");
		
	}
	
	
	public static void main(String args[])
	{
		
		getData1();
	}
	



	


		
		

	
//		//Hashtable[] excelql = excelDataReader(
//				System.getProperty("user.dir")
//						+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
//				"SELECT * FROM test2 WHERE Testcase_ID = 'Verify_admin_login'");
////		for (Hashtable hashtable : excelql)
////		{
////			Enumeration<String> keys = hashtable.keys();
////	        while (keys.hasMoreElements()) {
////	            String key = keys.nextElement();
////	            System.out.println("Key: " + key + ", Value: " + hashtable.get(key));
////	        }
////		}
//		return excelql;
	

//
////Negative Test Case
	/*@SuppressWarnings("unchecked")
	@DataProvider(name = "getNegativeData")
	public  Hashtable<String, String>[] getNegativeData() throws IOException 
	{
		 log.info("login  the user and fetching the data from negative data provider excel");

		String sheetname = System.getProperty("sheetname");
        String EXcelfilepath = System.getProperty("EXcelfilepath");
        
       
            sheetname = "Sheet2";  // Default sheetname
        

            EXcelfilepath = "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx";  // Default file path
        
        Hashtable<String, String>[] data = null;
       System.out.println(sheetname +" "+ EXcelfilepath);
       
		// sheetname = "Sheet2";
		// EXcelfilepath = "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx";
		return excelDataReader(
				System.getProperty("user.dir")
						+ EXcelfilepath,
				"SELECT * FROM "+sheetname+" WHERE Testcase_ID ='Verify_negative_admin_login' AND RUN= 'YES'");
			}
			*/
/*
	//----------------------------------//
	//ProfileManagement//
	//creation_of_Inbound_profile//

		@DataProvider
		public Hashtable[] creation_of_Inbound_profile() throws IOException {
			log.info("getting the createuser data from excel" + driver.getTitle());
			return excelDataReader(
					System.getProperty("user.dir")
							+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
					"SELECT * FROM Sheet2 WHERE Testcase_ID='creation_of_inbound_profile'");
		}

//createuser admin
	@DataProvider
	public Hashtable[] getcreateuserData() throws IOException {
		log.info("getting the createuser data from excel" + driver.getTitle());
		return excelDataReader(
				System.getProperty("user.dir")
						+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
				"SELECT * FROM Sheet2 WHERE Testcase_ID='creation_of_admin_user'");
	}

	// createuser supervisor
	@DataProvider
	public Hashtable[] getcreateuserData03() throws IOException {
		log.info("getting the createuser data from excel" + driver.getTitle());
		return excelDataReader(
				System.getProperty("user.dir")
						+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
				"SELECT * FROM createuser WHERE Testcase_ID='creation_of_supervisor_user' AND Run = 'YES'");
	}



	// delete_admin_user
	@DataProvider
	public Hashtable[] delete_admin_user() throws IOException {
		log.info("getting the createuser data from excel" + driver.getTitle());
		return excelDataReader(
				System.getProperty("user.dir")
						+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
				"SELECT * FROM createuser WHERE Testcase_ID='deletion_of_admin_user' AND Run = 'YES'");

	}

	
//----------------------------------//
//ProfileManagement//


//creation_of_Inbound_UI_profile//
	@DataProvider
	public Hashtable[] creation_of_Inbound_UI_profile() throws IOException {
		log.info("getting the createuser data from excel" + driver.getTitle());
		return excelDataReader(
				System.getProperty("user.dir")
						+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
				"SELECT * FROM InboundUI WHERE Testcase_ID='creation_of_InboundUI' AND Run = 'YES'");
	}

	@DataProvider
	public Hashtable[] creation_of_tsapi() throws IOException {
		log.info("getting the createuser data from excel" + driver.getTitle());
		return excelDataReader(
				System.getProperty("user.dir")
						+ "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx",
				"SELECT * FROM Tsapi WHERE Testcase_ID='creation_of_tsapi' AND Run = 'YES'");
	}

	
//keyname 
	}
	*/


	

	}

	//-------

