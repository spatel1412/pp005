package AvayaProfilerManager.testcomponent;

import java.io.IOException;
import java.util.Hashtable;
import org.openqa.selenium.WebDriver;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import java.lang.reflect.Field;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import AvayaProfilerManager.resources.ExtentReporterPP;


public class SuiteListener extends BaseTest implements ISuiteListener,ITestListener {

	ExtentTest test;
	ExtentReports extent = ExtentReporterPP.getReportObject();
	WebDriver driver;
	ThreadLocal<ExtentTest> extentTest = new ThreadLocal<ExtentTest>(); // Thread safe
	//ThreadLocal<ITestResult> t2 = new ThreadLocal<ITestResult>();

	@SuppressWarnings("unchecked")
	@Override
	public void onTestStart(ITestResult result) {
		
		//Hashtable<String, String> testData = (Hashtable<String, String>) result.getTestContext().getAttribute("testData");
//		 System.out.println("Test Data56565: " + testData);
//	        // Do something with the test data
//	        if (testData != null) {
//	            System.out.println("Test Data: " + testData);
//		
//	        }
		// TODO Auto-generated method stub
		test = extent.createTest(result.getMethod().getMethodName());

		//test = extent.createTest(testData.get("Testcase_ID"));
//		for(Field S : result.getClass().getFields())
//		{test = extent.createTest(S.toString());
		
		extentTest.set(test);// unique thread id(ErrorValidationTest)->test
		
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		extentTest.get().log(Status.PASS, "Test Passed");

	}

	@Override
	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		//test.log(Status.FAIL, "Test Passed");
		extentTest.get().fail(result.getThrowable());
		//t2.set(result);
		
		
		// Screenshot, Attach to report
		
		try {
			//System.out.println(" driver  "+ result.getTestClass().getRealClass().getField("driver") );
			  driver = (WebDriver)result.getTestClass().getRealClass().getField("driver").get(result.getInstance());

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String filePath = null;
		try {
System.out.println(result.getMethod().getMethodName() +"    "+driver+"hello");
			filePath = getScreenShot(result.getMethod().getMethodName(), driver);
			
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		extentTest.get().addScreenCaptureFromPath(filePath, result.getMethod().getMethodName());

		

	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		extent.flush();

	}

}

//