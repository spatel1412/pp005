package AvayaProfilerManager.testcomponent;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.*;
import org.testng.annotations.BeforeClass;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import java.util.Hashtable;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fasterxml.jackson.databind.ObjectMapper;

import AvayaProfilerManager.pageobjects.LoginpagePP;
import AvayaProfilerManager.MainClass;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.core.util.JsonParserSequence;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.io.FileHandler;

public class BaseTest {

	private static final Logger log = LogManager.getLogger(BaseTest.class);
	protected WebDriver driver;
	protected LoginpagePP login;
	Properties prop;
	//String default_Filename = "default.properties";
	private Fillo fillo;

	public WebDriver initializeDriver(String browserName) throws IOException {

		//browserName = prop.getProperty("browser");

		System.out.println(browserName);

		if (browserName.equalsIgnoreCase("chrome")) 
		{
//			
	 WebDriverManager.chromedriver().setup();
//		         this.driver = new ChromeDriver();
			ChromeOptions options = new ChromeOptions(); 
			options.setAcceptInsecureCerts(true);
		//	System.setProperty("webdriver.chrome.driver", "C:\\Users\\patel806\\Downloads\\chromedriver.exe");
			 this.driver = new ChromeDriver(options);
		} 
		
		else if (browserName.equalsIgnoreCase("firefox"))
		{
			// firefox
		}

		else if (browserName.equalsIgnoreCase("edge")) 
		{
			// edge
			WebDriverManager.edgedriver().setup();
			EdgeOptions options = new EdgeOptions();
			options.setAcceptInsecureCerts(true);
			//System.setProperty("webdriver.edge.driver", "C:\\Users\\patel806\\Downloads\\msedgedriver.exe");
			this.driver = new EdgeDriver(options);
		}

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		return driver;

	}

	public List<HashMap<String, String>> getJsonDataToMap(String filePath) throws IOException

	{// read json to string
		String jsonContent = FileUtils.readFileToString(new File(filePath), StandardCharsets.UTF_8);

		// String to hashmap
		ObjectMapper mapper = new ObjectMapper();

		List<HashMap<String, String>> data = mapper.readValue(jsonContent,
				new TypeReference<List<HashMap<String, String>>>() {
				});

		return data;

	}

	// Utility to take screenshots
//	public String getScreenshot(String testCaseName, WebDriver driver) throws IOException {
//		String screenshotPath = null;
//		TakesScreenshot ts = (TakesScreenshot) driver;
//		File source = ts.getScreenshotAs(OutputType.FILE);
//		File file = new File(System.getProperty("user.dir") + "\\reports\\" + testCaseName + ".png");
//		FileUtils.copyFile(source, file);
//		return System.getProperty("user.dir") + "\\reports\\" + testCaseName + ".png";
//
//	}

	// Utility to take screenshots
	 public String getScreenShot(String testCaseName, WebDriver driver) throws IOException {
          
		 String screenshotPath = null;
             try {
	            //take screenshot and save it in a file
	            File sourceFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	            //copy the file to the required path

	            File destinationFile = new File(System.getProperty("user.dir") + "\\reports\\" + testCaseName + ".png");

	            FileHandler.copy(sourceFile, destinationFile);

	            String[] relativePath = destinationFile.toString().split("reports");

	            screenshotPath = ".\\" + relativePath[1];

	        } catch (Exception e) {

	            System.out.println("Failure to take screenshot " + e);

	        }

	        return screenshotPath;

	    }
	

	
	// getting the properties from the global file
	// url
	public Properties getProperties(String filename) throws IOException {

		this.prop = new Properties();
		FileInputStream fis = new FileInputStream(

				System.getProperty("user.dir") + "//testcasedata//" + filename);
		prop.load(fis);
		return prop;
	}

	@Parameters({"browserName"})
	@BeforeClass(alwaysRun = true)
	public LoginpagePP launchApplication(String browserName) throws IOException 
	{
		getProperties("phonepe.properties");
		//String properties_file = prop.getProperty("url");
		//getProperties(properties_file);
		this.driver = initializeDriver(browserName);

		login = new LoginpagePP(driver);
		String URL = prop.getProperty("url");
		System.out.println("team"+URL);
		driver.get(URL);
	
	
		return login;
		}

	@AfterClass(alwaysRun = true)
	public void teardown() {

		driver.close();
	}

	// ---FilloAPi Excel data fetching
	
	public static Hashtable[] excelDataReader(String filePath, String query) {

		Hashtable[] htRow = null;
		boolean bFound = false;

		int iRowCnt = 0, iRowCounter = 0;
		String sQuery = "";

		log.info(sQuery);
		try {
			log.info("Entering into Method : " + Thread.currentThread().getStackTrace()[1].getMethodName());
			Recordset rsExcelRow = readExcelDatabase(filePath, query);
			iRowCnt = rsExcelRow.getCount();
			htRow = new Hashtable[iRowCnt];
			ArrayList<String> rsmd = rsExcelRow.getFieldNames();
			int iColumnCount = rsmd.size();
			log.info(iColumnCount);

			while (rsExcelRow.next()) {
				Hashtable htTemp = new Hashtable();

				// log.info(rsmd);

				for (int i = 0; i < iColumnCount; i++) {

					// log.info(rsmd.get(i)+ " " +rsExcelRow.getField(rsmd.get(i)));
					htTemp.put(rsmd.get(i), rsExcelRow.getField(rsmd.get(i)));

				}
				// log.info("Insert -->"+ htTemp);
				htRow[iRowCounter] = htTemp;
				iRowCounter++;
			}

		} catch (Exception e) {
			log.error(" test Exception occurred in {getAllExcelRow} method..." + e);

		}

		return htRow;

	}

	public static Recordset readExcelDatabase(String sExcelFileName, String sSQLQuery) throws Exception {

		Recordset rsData = null;

		Fillo fillo = new Fillo();
		com.codoid.products.fillo.Connection connection = fillo.getConnection(sExcelFileName);
		rsData = connection.executeQuery(sSQLQuery);

		// recordset.close();
		// connection.close();
		return rsData;
	}
	
	
		


	

	    // Updated to return Hashtable[] directly
	
	
	 /*  @DataProvider(name = "getNegativeData")
	    public static Hashtable<String, String>[] getNegativeData(String sheetname, String EXcelfilepath) {
	      
	    	 if (sheetname == null || sheetname.isEmpty()) {
	    	        sheetname = "Sheet2";  // Default sheetname
	    	    }

	    	    if (EXcelfilepath == null || EXcelfilepath.isEmpty()) {
	    	        EXcelfilepath = "\\src\\test\\java\\AvayaProfilerManager\\data\\PhonePeprofilermanagerdata.xlsx";  // Default file path
	    	    }
	        try {
				return  excelDataReader(
						System.getProperty("user.dir")
						+ EXcelfilepath,
				"SELECT * FROM "+sheetname+" WHERE Testcase_ID ='Verify_negative_admin_login' AND RUN= 'YES'");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	    }
	*/
	
	
	
	
	
	/**
	 * This method is used to Retrieves all the excel rows for the respective test case Name(column).
	 *
	 * @param    sExcelFileName Excel file Name
	 * @param    sSheetName Name of Excel sheet.
	 * @param    sTestCaseName Excel sheet column value Name
	 * @return   Hashtable-array with excel column Names and values
	 *
	 */
	/*public Hashtable[] getAllExcelRow(String sExcelFileName, String sSheetName, String sTestCaseName){

		Hashtable[] htRow =null;
		boolean bFound =false;


		int iRowCnt = 0, iRowCounter=0;
		String sQuery="";
		sQuery = "Select * from " + sSheetName + " where Testcase_ID='" + sTestCaseName + "' and TExecute='Yes'";
		log.info(sQuery);
		try{
			log.info("Entering into Method : " +  Thread.currentThread().getStackTrace()[1].getMethodName());
			Recordset rsExcelRow = readExcelDatabase(sExcelFileName, sQuery);
			iRowCnt=rsExcelRow.getCount();
			htRow = new Hashtable[iRowCnt];
			ArrayList<String> rsmd= rsExcelRow.getFieldNames();
			int iColumnCount = rsmd.size();
			log.info(iColumnCount);

			while(rsExcelRow.next())
			{
				Hashtable htTemp = new Hashtable();

				// log.info(rsmd);

				for(int i=0;i<iColumnCount;i++)
				{

					//log.info(rsmd.get(i)+ " " +rsExcelRow.getField(rsmd.get(i)));
					htTemp.put(rsmd.get(i),rsExcelRow.getField(rsmd.get(i)));

				}
			//log.info("Insert -->"+ htTemp);
				htRow[iRowCounter]=htTemp;
				iRowCounter++;
			}
			

		} catch (Exception e) {
			log.error(" test Exception occurred in {getAllExcelRow} method..." + e);

		}

		return htRow;

	}
	
	
	
	
	/**
    This method is used to get Multiple excel row for Test Case details in the form of Hashtable array.
	 *
	 * @param   context     -   ITestContext object.
	 * @return   Hashtable[] - return test case details.
	 *
	 */
  /*public Hashtable[] getAllTestDetails(ITestContext context){
		;
		Hashtable[] hData = null ;
		try{
			ITestResult iTestResult;
			log.info("Entering into Method : " +  Thread.currentThread().getStackTrace()[1].getMethodName());

			//Get Excel File Name
			//String sExcelFileName = SuiteListener.getAccess().getParameter("dataFile");
			String sExcelFileName = context.getCurrentXmlTest().getTestParameters().get("dataFile");

			if (sExcelFileName == null){
				//sExcelFileName = SuiteListener.getAccess().getName().toString().trim()+".xls";
				log.error("Input [dataFile] parameter is missing for Test Case -[" + context.getCurrentXmlTest().getName().toString().trim()+"]. Suite Name - [" + SuiteListener.getAccess().getName().toString() +"]");
				return hData;
			}

			//Get Excel Data Sheet File Name

			String sSheetName = context.getCurrentXmlTest().getTestParameters().get("dataSheet");
			if (sSheetName == null){
				//sSheetName = context.getCurrentXmlTest().getXmlClasses().get(0).getName().toString();
				log.error("Specified [dataSheet] parameter is missing for Test Case -[" + context.getCurrentXmlTest().getName().toString().trim()+"]. Suite Name: ["+ SuiteListener.getAccess().getName().toString() +"]");
				return hData;
			}

			String[] sArrClassName= sSheetName.split("\\.");
			sSheetName = sArrClassName[sArrClassName.length-1];


			//Get Test Case Name from Suite xml file
			// String sTestCaseName = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getName().toString().trim();
			String sTestCaseName = context.getCurrentXmlTest().getName().toString().trim();
			sTestCaseName = sTestCaseName.replaceAll("'","''");
			//System.out.println(sTestCaseName);
			//String sTestCaseName =Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getTestParameters().get("tcID");

			hData = this.getAllExcelRow(EnvSetup.TEST_DATA_PATH+"/testcasedata/"+sExcelFileName,sSheetName,sTestCaseName);

			return hData;
		}
		catch (Exception e){
			log.info("Exception | getAllTestDetails|-------------"+e+"----------------");
			new ExceptionHandler(e,Thread.currentThread().getStackTrace()[1].getMethodName());
			return hData;
		}
	}

	*/
	

	
	/**
    This method is used to execute same Test for multiple or different data.
	 *
	 * @param   context  ITestContext global variable.
	 * @return   boolean return true if success otherwise false.
	 * #@Test(dataProviderClass = UtilityFun.class, dataProvider = "getDataProviderDetails")
	 * # Add above line to test/method where user want to do data driven.
	 */
	/*@DataProvider (name = "getDataProviderDetails")

	public static Hashtable[][] getDataProviderDetails(ITestContext context) {
		BaseTest objFun = new BaseTest();
		Hashtable[] hData = objFun.getAllTestDetails(context);
		Hashtable[][] result = null;
		if (hData != null ) {
			result = new Hashtable[hData.length][1];
			int iCnt=0;

			for (Hashtable h: hData) 

			{
				result[iCnt][0]=h;
				//System.out.println(h);

				iCnt++;
			}
		} else {
			result = new Hashtable[1][1];
			result[0][0] = null;

		}

		try{        	

			for (Hashtable h: hData) {
				//System.out.println("----------------------"+h);
				//System.out.println(h.get("FEAT").toString());
				EnvSetup.hTestDetails.put("FEAT",h.get("FEAT").toString()) ;
			}
		}
		catch (Exception e)
		{
			System.out.println(e);
			EnvSetup.hTestDetails.put("FEAT","NOFEAT") ;
		}
		return result;

	}

	
	*/
	
	
	
	
	
	

	
	
	/*
	 public void ExcelReader(String sExcelFileName, String sSQLQuery) throws Exception {
		 
		 Recordset rsData = null;
	        this.fillo = new Fillo();
	        com.codoid.products.fillo.Connection connection = fillo.getConnection(sExcelFileName);
			rsData = connection.executeQuery(sSQLQuery);
	    }

	    public Recordset readLocators(String filePath, String sheetName) {
	        String query = "SELECT * FROM " + sheetName;
	        Recordset recordset = null;

	        try {
	            recordset = fillo.executeQuery(filePath, query);
	            
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return recordset;
	    }

	    public void close() {
	        fillo.close();
	    } /*

	//new changes
//-------------------------------------------
    public static Object[][] getDropdownLocators(String excelFilePath) throws IOException {
    	
    	
    	FileInputStream fis = new FileInputStream(excelFilePath);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheetAt(0);

        int rowCount = sheet.getLastRowNum();
        int colCount = sheet.getRow(0).getLastCellNum();

        Object[][] data = new Object[rowCount][colCount];

        for (int i = 1; i <= rowCount; i++) {
            Row row = sheet.getRow(i);
            for (int j = 0; j < colCount; j++) {
                data[i - 1][j] = row.getCell(j).getStringCellValue();
            }
        }

        fis.close();
        return data;
        // Initialize your workbook and sheet
        // Loop through the rows and read the data
        // Create a 2D array with the data and return it
    }
	//-------------------
	
	public Recordset readExcelDatabase(String sExcelFileName, String sSQLQuery) throws Exception {

		Recordset rsData = null;

		Fillo fillo = new Fillo();
		com.codoid.products.fillo.Connection connection = fillo.getConnection(sExcelFileName);
		rsData = connection.executeQuery(sSQLQuery);

		// recordset.close();
		// connection.close();
		return rsData;
	}
	//----------------
	
	// Example using Apache POI
	/*public class ExcelReader {
	    private FileInputStream fileInputStream;
	    private XSSFWorkbook workbook;
	    private XSSFSheet sheet;

	    public ExcelReader(String filePath) {
	        try {
	            fileInputStream = new FileInputStream(filePath);
	            workbook = new XSSFWorkbook(fileInputStream);
	            sheet = workbook.getSheet("Locators"); // Assuming "Locators" is the sheet name
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    public Object[][] getLocatorData() {
	        int rowCount = sheet.getLastRowNum();
	        Object[][] data = new Object[rowCount][4];

	        for (int i = 1; i <= rowCount; i++) {
	            data[i - 1][0] = sheet.getRow(i).getCell(0).getStringCellValue(); // PageName
	            data[i - 1][1] = sheet.getRow(i).getCell(1).getStringCellValue(); // ElementName
	            data[i - 1][2] = sheet.getRow(i).getCell(2).getStringCellValue(); // LocatorType
	            data[i - 1][3] = sheet.getRow(i).getCell(3).getStringCellValue(); // LocatorValue
	        }

	        return data;
	    }

	    public void close() {
	        try {
	            workbook.close();
	            fileInputStream.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}

*/
}